#! /Users/ashutosh/perl5/perlbrew/perls/perl-5.8.8/bin/perl


use strict;

use lib ".";

use Time::Local;
use managed_record;
use topic;
use camp;
use support;
use statement;
use DBI;

use Data::Dumper;


my %db_details = (
    db_user  => 'root',
    db_pass  => '',
    db_host  => '127.0.0.1',
    db_name  => 'canonizer',
    db_dsn   => 'dbi:mysql:dbname=canonizer'
);

# Initially Static
my $topic_num = 88;

our $dbh = DBI->connect(
                $db_details { db_dsn },
                $db_details { db_user },
                $db_details { db_pass },
                {
                    PrintError       => 0,
                    RaiseError       => 1
                }
            );

# my $debug = 0; # no debug
# my $debug = 1; # just status
my $debug = 2; # output content.


my $sth = $dbh->prepare("select * from person");
$sth->execute();

print Dumper($sth->rows);

my $rs;

$rs->{'record_id'}  = 1;
$rs->{'topic_name'} = 'Brent';


# my $foo_topic = topic->new_rs ($rs);

my $topic = topic10->get_topic_record_info($topic_num);

my $new_topic_num = topic10->new_topic_num(
                        $topic_num, 'as_of_1', $topic->{submit_time}
                    );


my $mind_expert_score = topic10->canonizer_score(
                            'mind_experts', 38
                        );

# $test_topic = new_topic_rs topic ($rs);

# $test_topic->{topic_name} = "Brent";

#print("Hello $foo_topic->{topic_name}!");

print Dumper($new_topic_num);


###

package topic10;

use DBI;
use func;
use canonizers;

=head1 METHOD
    NAME: get_topic_record_info
    DESC: Return the Topic Information from the Canonizer Database

    PARAMS:
        $self: Class Variable
        $topic_num: Topic Number
=cut

sub get_topic_record_info {

    my ($self, $topic_num) = @_;

    my $query = "select id, topic_name, namespace, topic_num, note,
                 submitter_nick_id, submit_time, go_live_time, proposed, replacement,
                 objector_nick_id, object_time, object_reason from topic
                 where topic_num = ?
                 order by go_live_time DESC";

    my $sth = $dbh->prepare($query);

    $sth->execute($topic_num);

    return $sth->fetchrow_hashref;
}

sub new_topic_num {

    my ($self, $topic_num, $as_of_mode, $as_of_date) = @_;

	my $as_of_clause = '';
	if ($as_of_mode eq 'review') {
		# no as_of_clause;
	} elsif ($as_of_mode eq 'as_of') {
		$as_of_clause = 'and go_live_time < ' . parse_as_of_date($as_of_date);
    } else {
		$as_of_clause = 'and go_live_time < ' . time;
    }

	my $selstmt = "select id, topic_name, namespace, topic_num, note, submit_time,
    submitter_nick_id, go_live_time, objector_nick_id, object_time, object_reason,
    proposed, replacement from topic where topic_num = $topic_num and objector_nick_id is null $as_of_clause order by go_live_time desc limit 1";

	my $sth = $dbh->prepare($selstmt) || die "Failed to prepair $selstmt";

	$sth->execute() || die "Failed to execute $selstmt";

	return $sth->fetchrow_hashref;
}

=head2 METHOD
    NAME: canonizer_score
    DESCRIPTION: Calculate the alogrithm Score


=cut

sub canonizer_score {
    my ($self, $algo_name, $nick_id, $as_of_date) = @_;

    my $score = canonizers::mind_experts($dbh, $nick_id, '');

    print "NickName: $nick_id, Score: $score\n";
}


sub parse_as_of_date {
	my $as_of_str = $_[0];

    my $return_val;

	if ($as_of_str =~ m|(\d\d)/(\d\d)/(\d\d)|) {
		my $year = $1 + 100;
		my $month = $2 - 1;
		my $day = $3;
		$return_val = &Time::Local::timegm(0, 0, 0, $day, $month, $year);
		return($return_val);
	} else {
		return(0);
	}
}

1;
